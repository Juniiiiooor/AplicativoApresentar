@echo off
setlocal
cd /d "%~dp0"
set "TCL_LIBRARY=%~dp0tcl\tcl8.6"
set "TK_LIBRARY=%~dp0tcl\tk8.6"
start "" /D "%~dp0" "%~dp0pythonw.exe" "%~dp0desktop\app.py"
exit /b 0
